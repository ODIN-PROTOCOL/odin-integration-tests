import click


@click.group()
def cli():
    """BandChain's flusher utility program."""
    pass
