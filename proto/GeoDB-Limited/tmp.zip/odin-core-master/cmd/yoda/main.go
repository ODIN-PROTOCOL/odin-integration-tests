package main

import "github.com/GeoDB-Limited/odin-core/yoda"

func main() {
	yoda.Main()
}
