# start bandchain
bandd start --rpc.laddr tcp://0.0.0.0:26657
