package types

const (
	EventTypeExchange = "exchange"
)

const (
	AttributeKeyRequester     = "requester"
	AttributeKeyAmount        = "amount"
	AttributeKeyExchangeDenom = "exchange_denom"
)
