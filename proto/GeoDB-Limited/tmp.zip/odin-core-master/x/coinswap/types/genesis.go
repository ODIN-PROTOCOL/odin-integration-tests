package types

func (g GenesisState) Validate() error { return nil }
