package types

const (
	EventTypeBuyCoins = "buy_coins"
)

const (
	AttributeKeyRequester     = "requester"
	AttributeKeyAmount        = "amount"
	AttributeKeyExchangeDenom = "exchange_denom"
)
