package helpers

// SimAppChainID hardcoded chainID for simulation
const (
	SimAppChainID = "band-app"
)
