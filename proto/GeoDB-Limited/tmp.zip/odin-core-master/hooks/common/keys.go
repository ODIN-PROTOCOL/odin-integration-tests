package common

const (
	AppHook = "odin"
)
